A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/rzdzeR.

 This is created using the amazing MorphSVG plugin from GreenSock.

Follow the hashtag #dailymorph on Twitter to see 7 days of morphing animations.